# automatically generated with generateRandomGraphs.py -------
actionset = [
'a',
'b',
'c',
'd',
'e',
]
valuationdomain = {'min':0, 'med':50, 'max':100}
relation = {
'a': {
'a':0,
'b':51,
'c':0,
'd':0,
'e':0,
},
'b': {
'a':0,
'b':0,
'c':100,
'd':100,
'e':50,
},
'c': {
'a':0,
'b':0,
'c':0,
'd':100,
'e':100,
},
'd': {
'a':100,
'b':0,
'c':0,
'd':0,
'e':0,
},
'e': {
'a':0,
'b':0,
'c':0,
'd':0,
'e':0,
},

}
