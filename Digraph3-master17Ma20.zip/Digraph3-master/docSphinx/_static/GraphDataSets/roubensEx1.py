# Le temps des noyaux, Bisdorff-Roubens -------
actionset = [
'a',
'b',
'c',
'd',
'e',
'f',
]
valuationdomain = {'min':0, 'med':1, 'max':2}
relation = {
'a': {
'a':0,
'b':2,
'c':2,
'd':0,
'e':0,
'f':0,
},
'b': {
'a':0,
'b':0,
'c':2,
'd':0,
'e':0,
'f':0,
},
'c': {
'a':2,
'b':0,
'c':0,
'd':0,
'e':2,
'f':0,
},
'd': {
'a':0,
'b':2,
'c':0,
'd':0,
'e':0,
'f':2,
},
'e': {
'a':0,
'b':0,
'c':0,
'd':2,
'e':0,
'f':0,
},
'f': {
'a':0,
'b':0,
'c':0,
'd':0,
'e':0,
'f':0,
},
}
