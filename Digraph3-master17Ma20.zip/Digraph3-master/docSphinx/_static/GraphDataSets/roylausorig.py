# exemple ROY de Lausanne  #
actionset = ['a', 'b', 'c']
valuationdomain = {'min':0.0, 'med':50.0, 'max':100.0}
relation = {
    'a':{
      'a':100.0,
      'b':55.0,
      'c':100.0},
     'b':{
      'a':0.0,
      'b':100.0,
      'c':100.0},
     'c':{
      'a':55.0,
      'b':55.0,
      'c':100.0}
}
