# computed hyper graph from  <module 'bouyssou11Oct05' from '/home/bisi/Current/mindom/bouyssou11Oct05.pyc'>
actionset = [
'a',
'b',
'c',
'd',
]
valuationdomain =  {'med': 50, 'max': 100, 'min': 0}
relation = {
'a': {
'a': 0,
'b': 100,
'c': 100,
'd': 0,
},
'b': {
'a': 0,
'b': 0,
'c': 100,
'd': 100,
},
'c': {
'a': 0,
'b': 0,
'c': 0,
'd': 100,
},
'd': {
'a': 0,
'b': 0,
'c': 0,
'd': 0,
},
}
