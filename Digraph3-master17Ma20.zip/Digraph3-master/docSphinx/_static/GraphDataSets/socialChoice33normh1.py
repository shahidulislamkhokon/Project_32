# computed hyper graph from  <module 'socialChoice33norm'>
actionset = [
'a',
'c',
'b',
'e',
'd',
'_c_b_d_',
]
valuationdomain =  {'med': 50, 'max': 100, 'min': 0}
relation = {
'a': {
'a': 100,
'c': 43,
'b': 43,
'e': 71,
'd': 43,
'_c_b_d_': 43,
},
'c': {
'a': 57,
'c': 100,
'b': 43,
'e': 57,
'd': 71,
'_c_b_d_': 100,
},
'b': {
'a': 57,
'c': 57,
'b': 100,
'e': 86,
'd': 43,
'_c_b_d_': 100,
},
'e': {
'a': 29,
'c': 43,
'b': 14,
'e': 100,
'd': 14,
'_c_b_d_': 43,
},
'd': {
'a': 57,
'c': 29,
'b': 57,
'e': 86,
'd': 100,
'_c_b_d_': 100,
},
'_c_b_d_': {
'a': 57,
'c': 100,
'b': 100,
'e': 86,
'd': 100,
'_c_b_d_': 0,
},
}
