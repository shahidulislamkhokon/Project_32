# relation : socialChoice33norm
actionset= ['a',
'b',
'c',
'd',
'e']
valuationdomain = { 'min':0, 'med':50, 'max': 100}
relation = {

'a': {
'a': 100,
'b': 43,
'c': 43,
'd': 43,
'e': 71,
},
'b': {
'a': 57,
'b': 100,
'c': 57,
'd': 43,
'e': 86,
},
'c': {
'a': 57,
'b': 43,
'c': 100,
'd': 71,
'e': 57,
},
'd': {
'a': 57,
'b': 57,
'c': 29,
'd': 100,
'e': 86,
},
'e': {
'a': 29,
'b': 14,
'c': 43,
'd': 14,
'e': 100,
},}
