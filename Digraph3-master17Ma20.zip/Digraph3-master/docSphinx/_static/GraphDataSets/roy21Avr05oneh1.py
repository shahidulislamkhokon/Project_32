# computed hyper graph from  <module 'roy21Avr05one' from '/home/bisi/Current/mindom/roy21Avr05one.py'>
actionset = [
'a',
'c',
'b',
'e',
'd',
'_a_b_d_',
]
valuationdomain =  {'med': 50, 'max': 100, 'min': 0}
relation = {
'a': {
'a': 0,
'c': 0,
'b': 51,
'e': 0,
'd': 0,
'_a_b_d_': 100,
},
'c': {
'a': 0,
'c': 0,
'b': 0,
'e': 100,
'd': 51,
'_a_b_d_': 51,
},
'b': {
'a': 0,
'c': 100,
'b': 0,
'e': 50,
'd': 100,
'_a_b_d_': 100,
},
'e': {
'a': 0,
'c': 0,
'b': 0,
'e': 0,
'd': 0,
'_a_b_d_': 0,
},
'd': {
'a': 100,
'c': 0,
'b': 0,
'e': 0,
'd': 0,
'_a_b_d_': 100,
},
'_a_b_d_': {
'a': 100,
'c': 100,
'b': 100,
'e': 50,
'd': 100,
'_a_b_d_': 0,
},
}
