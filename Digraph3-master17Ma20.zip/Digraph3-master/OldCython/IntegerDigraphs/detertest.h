#define ABS(a) ((a) < 0 ? (-a) : (a))
#define cMAX(a,b) ((a) > (b) ? (a) : (b))
#define cMIN(a,b) ((a) < (b) ? (a) : (b))  
